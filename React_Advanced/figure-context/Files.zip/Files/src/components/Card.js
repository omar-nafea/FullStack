import { Heading, HStack, Image, Text, VStack, Box } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
    <Box
      backgroundColor="white"
      borderRadius="lg"
      boxShadow="lg"
      overflow="hidden"
    >
      {/* Image Section */}
      <Image src={imageSrc} alt={title} width="100%" height="200px" objectFit="cover" />

      {/* Text Content */}
      <VStack align="start" p={6} spacing={4}>
        <Heading as="h3" size="md">
          {title}
        </Heading>
        <Text color="gray.600">{description}</Text>
        <HStack spacing={2} align="center">
          <Text fontWeight="bold" color="teal.500">
            See more
          </Text>
          <FontAwesomeIcon icon={faArrowRight} size="1x" color="teal" />
        </HStack>
      </VStack>
    </Box>
  );
};

export default Card;
